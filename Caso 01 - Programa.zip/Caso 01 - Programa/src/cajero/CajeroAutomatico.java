package cajero;
public class CajeroAutomatico {
     public void ejecutarCajero() {
        
         Cajero cajero = new Cajero();
         cajero.mostrarMenu();
         
    }
}
